REST-only homework package.

Endpoints implemented (10+):
- auth: register, confirmCode, login, me, logout
- music: getTracks, getAlbums, getGenres, getAlbumTracks
- library: getLibrary, addToLibrary, removeFromLibrary
- search: search
- profile: getProfile, updateProfile
- pro: buyPro

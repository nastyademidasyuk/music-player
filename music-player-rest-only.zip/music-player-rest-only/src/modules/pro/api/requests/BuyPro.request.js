/** @typedef {{ planId?: string }} BuyProRequest */
export {};

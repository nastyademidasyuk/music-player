import { apiClient } from "../../../../shared/api/apiClient";

export function buyPro(data = {}) {
  return apiClient("/payment/pro", {
    method: "POST",
    body: JSON.stringify(data)
  });
}

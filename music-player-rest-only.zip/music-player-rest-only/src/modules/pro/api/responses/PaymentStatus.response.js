/** @typedef {{ status: "pending"|"paid"|"failed", orderId?: string }} PaymentStatusResponse */
export {};

/** @typedef {{ email: string, password: string }} RegisterRequest */
export {};

/** @typedef {{ email: string, code: string }} ConfirmCodeRequest */
export {};

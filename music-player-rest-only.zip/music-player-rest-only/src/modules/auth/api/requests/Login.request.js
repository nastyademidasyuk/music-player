/** @typedef {{ email: string, password: string }} LoginRequest */
export {};

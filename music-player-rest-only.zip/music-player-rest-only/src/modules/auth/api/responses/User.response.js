/** @typedef {{ id: string, email: string, name?: (string|null) }} UserResponse */
export {};

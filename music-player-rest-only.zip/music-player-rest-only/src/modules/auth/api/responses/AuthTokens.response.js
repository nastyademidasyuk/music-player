/** @typedef {{ accessToken: string, refreshToken?: string }} AuthTokensResponse */
export {};

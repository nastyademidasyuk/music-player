import { apiClient } from "../../../../shared/api/apiClient";

const AUTH_URL = "/auth";

export function register(data) {
  return apiClient(`${AUTH_URL}/register`, {
    method: "POST",
    body: JSON.stringify(data)
  });
}

export function confirmCode(data) {
  return apiClient(`${AUTH_URL}/confirm`, {
    method: "POST",
    body: JSON.stringify(data)
  });
}

export function login(data) {
  return apiClient(`${AUTH_URL}/login`, {
    method: "POST",
    body: JSON.stringify(data)
  });
}

export function me() {
  return apiClient(`${AUTH_URL}/me`, { method: "GET" });
}

export function logout() {
  return apiClient(`${AUTH_URL}/logout`, { method: "POST" });
}

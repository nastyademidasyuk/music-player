import { apiClient } from "../../../../shared/api/apiClient";

export function getTracks(params = {}) {
  const qs = new URLSearchParams();
  if (params.page != null) qs.set("page", String(params.page));
  if (params.limit != null) qs.set("limit", String(params.limit));
  if (params.genreId) qs.set("genreId", params.genreId);
  const q = qs.toString();
  return apiClient(`/tracks${q ? `?${q}` : ""}`, { method: "GET" });
}

export function getAlbums(params = {}) {
  const qs = new URLSearchParams();
  if (params.page != null) qs.set("page", String(params.page));
  if (params.limit != null) qs.set("limit", String(params.limit));
  const q = qs.toString();
  return apiClient(`/albums${q ? `?${q}` : ""}`, { method: "GET" });
}

export function getGenres() {
  return apiClient("/genres", { method: "GET" });
}

export function getAlbumTracks(params) {
  return apiClient(`/albums/${params.albumId}/tracks`, { method: "GET" });
}

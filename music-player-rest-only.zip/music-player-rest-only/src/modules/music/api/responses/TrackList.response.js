/** @typedef {{ items: any[], total: number }} TrackListResponse */
export {};

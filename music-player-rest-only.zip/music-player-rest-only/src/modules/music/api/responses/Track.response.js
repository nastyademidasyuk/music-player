/** @typedef {{ id: string, title: string, artist: string, duration: number, audioUrl?: (string|null), albumId?: (string|null) }} TrackResponse */
export {};

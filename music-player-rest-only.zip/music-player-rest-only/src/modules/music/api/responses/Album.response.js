/** @typedef {{ id: string, title: string, artist: string, coverUrl?: (string|null) }} AlbumResponse */
export {};

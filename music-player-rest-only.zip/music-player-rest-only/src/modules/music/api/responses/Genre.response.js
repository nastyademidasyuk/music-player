/** @typedef {{ id: string, name: string }} GenreResponse */
export {};

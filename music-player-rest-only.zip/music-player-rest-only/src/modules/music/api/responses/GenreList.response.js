/** @typedef {{ items: any[] }} GenreListResponse */
export {};

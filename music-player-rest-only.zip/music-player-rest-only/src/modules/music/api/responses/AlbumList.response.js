/** @typedef {{ items: any[], total: number }} AlbumListResponse */
export {};

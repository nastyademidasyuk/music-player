/** @typedef {{}} GetGenresRequest */
export {};

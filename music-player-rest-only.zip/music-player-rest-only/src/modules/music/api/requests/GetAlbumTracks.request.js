/** @typedef {{ albumId: string }} GetAlbumTracksRequest */
export {};

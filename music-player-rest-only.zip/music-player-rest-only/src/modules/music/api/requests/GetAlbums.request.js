/** @typedef {{ page?: number, limit?: number }} GetAlbumsRequest */
export {};

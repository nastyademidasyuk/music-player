/** @typedef {{ items: any[], total: number }} LibraryListResponse */
export {};

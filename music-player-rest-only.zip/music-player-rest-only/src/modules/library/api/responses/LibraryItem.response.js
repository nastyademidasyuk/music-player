/** @typedef {{ trackId: string, addedAt: string }} LibraryItemResponse */
export {};

/** @typedef {{ trackId: string }} RemoveFromLibraryRequest */
export {};

/** @typedef {{ trackId: string }} AddToLibraryRequest */
export {};

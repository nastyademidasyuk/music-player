import { apiClient } from "../../../../shared/api/apiClient";

export function getLibrary(params = {}) {
  const qs = new URLSearchParams();
  if (params.page != null) qs.set("page", String(params.page));
  if (params.limit != null) qs.set("limit", String(params.limit));
  const q = qs.toString();
  return apiClient(`/library${q ? `?${q}` : ""}`, { method: "GET" });
}

export function addToLibrary(params) {
  return apiClient(`/library/${params.trackId}`, { method: "POST" });
}

export function removeFromLibrary(params) {
  return apiClient(`/library/${params.trackId}`, { method: "DELETE" });
}

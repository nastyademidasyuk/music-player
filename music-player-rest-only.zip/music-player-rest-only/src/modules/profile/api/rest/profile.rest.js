import { apiClient } from "../../../../shared/api/apiClient";

export function getProfile() {
  return apiClient("/profile", { method: "GET" });
}

export async function updateProfile(data) {
  await apiClient("/profile", {
    method: "PATCH",
    body: JSON.stringify(data)
  });
}

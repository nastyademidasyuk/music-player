/** @typedef {{ id: string, email: string, name?: (string|null), avatarUrl?: (string|null), country?: (string|null) }} ProfileResponse */
export {};

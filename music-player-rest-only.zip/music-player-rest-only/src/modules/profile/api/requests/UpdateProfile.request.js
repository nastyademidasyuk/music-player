/** @typedef {{ name?: (string|null), avatarUrl?: (string|null), country?: (string|null) }} UpdateProfileRequest */
export {};

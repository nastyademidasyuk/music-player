import { apiClient } from "../../../../shared/api/apiClient";

export function search(params) {
  const qs = new URLSearchParams();
  qs.set("q", params.q);
  if (params.limit != null) qs.set("limit", String(params.limit));
  return apiClient(`/search?${qs.toString()}`, { method: "GET" });
}

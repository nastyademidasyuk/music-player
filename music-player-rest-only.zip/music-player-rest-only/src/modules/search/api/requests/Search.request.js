/** @typedef {{ q: string, limit?: number }} SearchRequest */
export {};

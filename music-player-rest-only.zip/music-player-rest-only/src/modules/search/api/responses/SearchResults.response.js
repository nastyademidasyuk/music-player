/** @typedef {{ tracks: any[], albums: any[] }} SearchResultsResponse */
export {};
